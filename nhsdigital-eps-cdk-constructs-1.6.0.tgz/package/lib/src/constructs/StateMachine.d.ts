import { IManagedPolicy, IRole, ManagedPolicy } from "aws-cdk-lib/aws-iam";
import { IKey } from "aws-cdk-lib/aws-kms";
import { IChainable, StateMachine } from "aws-cdk-lib/aws-stepfunctions";
import { Construct } from "constructs";
import { CfnDeliveryStream } from "aws-cdk-lib/aws-kinesisfirehose";
/**
 * Configuration for provisioning an Express Step Functions state machine
 * with logging and optional Splunk forwarding.
 */
export interface StateMachineProps {
    /** Stack name, used as prefix for resource naming and DNS records. */
    readonly stackName: string;
    /** Friendly state machine name used for both AWS resource and log naming. */
    readonly stateMachineName: string;
    /** Workflow definition chain rendered as the state machine definition body. */
    readonly definition: IChainable;
    /** Extra managed policies merged into the execution role when required. */
    readonly additionalPolicies?: Array<IManagedPolicy>;
    /** Retention period applied to the workflow CloudWatch log group. */
    readonly logRetentionInDays: number;
    /**
     * Optional KMS key for encrypting CloudWatch Logs.
     * Defaults to the shared account-level KMS key via CloudFormation import.
     */
    readonly cloudWatchLogsKmsKey?: IKey;
    /**
     * Optional IAM policy allowing CloudWatch to use the KMS key for encrypting logs.
     * Defaults to the shared account-level policy via CloudFormation import.
     */
    readonly cloudwatchEncryptionKMSPolicy?: IManagedPolicy;
    /**
     * Optional Kinesis Firehose delivery stream for forwarding logs to Splunk.
     * When not provided, falls back to a Kinesis Stream via CloudFormation import.
     */
    readonly splunkDeliveryStream?: CfnDeliveryStream;
    /**
     * Optional IAM role used by the Splunk subscription filter.
     * Defaults to the shared role via CloudFormation import.
     */
    readonly splunkSubscriptionFilterRole?: IRole;
    /**
     * Whether to create a subscription filter to forward logs to Splunk.
     * Defaults to true.
     */
    readonly addSplunkSubscriptionFilter?: boolean;
}
/** Creates an Express Step Functions workflow with CloudWatch logging and invoke permissions. */
export declare class ExpressStateMachine extends Construct {
    /** Managed policy that grants permission to start this workflow. */
    readonly executionPolicy: ManagedPolicy;
    /** Created Step Functions state machine resource. */
    readonly stateMachine: StateMachine;
    /**
     * Provisions an Express Step Functions workflow with logging, tracing, and invoke permissions.
     * @example
     * ```ts
     * const sm = new ExpressStateMachine(this, "MyWorkflow", {
     *   stackName: "my-service",
     *   stateMachineName: "my-service-workflow",
     *   definition: new Pass(this, "Start"),
     *   logRetentionInDays: 30,
     *   additionalPolicies: [myLambdaInvokePolicy]
     * })
     * // Attach the generated execution policy to an API Gateway role
     * apiGatewayRole.addManagedPolicy(sm.executionPolicy)
     * ```
     */
    constructor(scope: Construct, id: string, props: StateMachineProps);
}
