import { IManagedPolicy, IRole, ManagedPolicy } from "aws-cdk-lib/aws-iam";
import { IKey } from "aws-cdk-lib/aws-kms";
import { IChainable, StateMachine } from "aws-cdk-lib/aws-stepfunctions";
import { Construct } from "constructs";
import { CfnDeliveryStream } from "aws-cdk-lib/aws-kinesisfirehose";
export interface StateMachineProps {
    readonly stackName: string;
    readonly stateMachineName: string;
    readonly definition: IChainable;
    readonly additionalPolicies?: Array<IManagedPolicy>;
    readonly logRetentionInDays: number;
    /**
     * Optional KMS key for encrypting CloudWatch Logs.
     * Defaults to the shared account-level KMS key via CloudFormation import.
     */
    readonly cloudWatchLogsKmsKey?: IKey;
    /**
     * Optional IAM policy allowing CloudWatch to use the KMS key for encrypting logs.
     * Defaults to the shared account-level policy via CloudFormation import.
     */
    readonly cloudwatchEncryptionKMSPolicy?: IManagedPolicy;
    /**
     * Optional Kinesis Firehose delivery stream for forwarding logs to Splunk.
     * When not provided, falls back to a Kinesis Stream via CloudFormation import.
     */
    readonly splunkDeliveryStream?: CfnDeliveryStream;
    /**
     * Optional IAM role used by the Splunk subscription filter.
     * Defaults to the shared role via CloudFormation import.
     */
    readonly splunkSubscriptionFilterRole?: IRole;
    /**
     * Whether to create a subscription filter to forward logs to Splunk.
     * Defaults to true.
     */
    readonly addSplunkSubscriptionFilter?: boolean;
}
export declare class ExpressStateMachine extends Construct {
    readonly executionPolicy: ManagedPolicy;
    readonly stateMachine: StateMachine;
    constructor(scope: Construct, id: string, props: StateMachineProps);
}
