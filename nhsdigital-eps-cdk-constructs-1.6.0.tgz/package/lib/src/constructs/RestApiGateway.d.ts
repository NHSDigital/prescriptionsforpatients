import { RestApi } from "aws-cdk-lib/aws-apigateway";
import { IManagedPolicy, IRole } from "aws-cdk-lib/aws-iam";
import { Construct } from "constructs";
/** Configuration for creating a REST API with optional mTLS and log forwarding integrations. */
export interface RestApiGatewayProps {
    /** Stack name, used as prefix for resource naming and DNS records. */
    readonly stackName: string;
    /** Shared retention period for API and deployment-related log groups. */
    readonly logRetentionInDays: number;
    /** Truststore object key to enable mTLS; leave undefined to disable mTLS or when enableServiceDomain is false. */
    readonly mutualTlsTrustStoreKey: string | undefined;
    /** Enables creation of a second subscription filter to forward logs to CSOC. */
    readonly forwardCsocLogs: boolean;
    /** Destination ARN used by the optional CSOC subscription filter. */
    readonly csocApiGatewayDestination: string;
    /** Managed policies attached to the API Gateway execution role. */
    readonly executionPolicies: Array<IManagedPolicy>;
    /**
     * When true (default), creates the custom service domain, ACM certificate, and Route53 records.
     */
    readonly enableServiceDomain?: boolean;
}
/** Creates a regional REST API with standard logging, DNS, and optional mTLS/CSOC integration. */
export declare class RestApiGateway extends Construct {
    /** Created API Gateway instance. */
    readonly api: RestApi;
    /** IAM role assumed by API Gateway integrations. */
    readonly role: IRole;
    /**
     * Builds API Gateway infrastructure and validates CSOC forwarding configuration.
     * @example
     * ```ts
     * const api = new RestApiGateway(this, "MyApi", {
     *   stackName: "my-service",
     *   logRetentionInDays: 30,
     *   mutualTlsTrustStoreKey: "truststore.pem",
     *   forwardCsocLogs: true,
     *   csocApiGatewayDestination: "arn:aws:logs:eu-west-2:123456789012:destination:csoc",
     *   executionPolicies: [myLambdaInvokePolicy],
     *   enableServiceDomain: true
     * })
     * api.api.root.addResource("patients")
     * ```
     */
    constructor(scope: Construct, id: string, props: RestApiGatewayProps);
}
