import { RestApi } from "aws-cdk-lib/aws-apigateway";
import { IManagedPolicy, IRole } from "aws-cdk-lib/aws-iam";
import { Construct } from "constructs";
export interface RestApiGatewayProps {
    readonly stackName: string;
    readonly logRetentionInDays: number;
    readonly mutualTlsTrustStoreKey: string | undefined;
    readonly forwardCsocLogs: boolean;
    readonly csocApiGatewayDestination: string;
    readonly executionPolicies: Array<IManagedPolicy>;
}
export declare class RestApiGateway extends Construct {
    readonly api: RestApi;
    readonly role: IRole;
    constructor(scope: Construct, id: string, props: RestApiGatewayProps);
}
