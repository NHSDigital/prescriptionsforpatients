import { AccessLogFormat } from "aws-cdk-lib/aws-apigateway";
export declare const accessLogFormat: () => AccessLogFormat;
