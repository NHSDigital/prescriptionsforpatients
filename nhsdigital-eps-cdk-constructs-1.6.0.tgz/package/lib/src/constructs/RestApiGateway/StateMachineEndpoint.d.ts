import { IResource } from "aws-cdk-lib/aws-apigateway";
import { IRole } from "aws-cdk-lib/aws-iam";
import { HttpMethod } from "aws-cdk-lib/aws-lambda";
import { Construct } from "constructs";
import { ExpressStateMachine } from "../StateMachine.js";
/** Parameters used to create an API endpoint backed by a Step Functions Express workflow. */
export interface StateMachineEndpointProps {
    /** Parent API resource under which the state machine endpoint is added. */
    parentResource: IResource;
    /** Path segment used to create the child API resource. */
    readonly resourceName: string;
    /** HTTP verb bound to the Step Functions integration. */
    readonly method: HttpMethod;
    /** Invocation role used by API Gateway when starting workflow executions. */
    restApiGatewayRole: IRole;
    /** State machine wrapper construct providing the target workflow ARN and integration target. */
    stateMachine: ExpressStateMachine;
}
/** Adds an API Gateway resource/method that starts an Express Step Functions execution. */
export declare class StateMachineEndpoint extends Construct {
    /** API resource created by this construct. */
    resource: IResource;
    /** Wires request and response mapping templates for JSON and FHIR payload flows. */
    constructor(scope: Construct, id: string, props: StateMachineEndpointProps);
}
