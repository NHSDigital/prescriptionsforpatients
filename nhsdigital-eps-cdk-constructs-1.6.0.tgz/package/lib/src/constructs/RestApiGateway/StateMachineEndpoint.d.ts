import { IResource } from "aws-cdk-lib/aws-apigateway";
import { IRole } from "aws-cdk-lib/aws-iam";
import { HttpMethod } from "aws-cdk-lib/aws-lambda";
import { Construct } from "constructs";
import { ExpressStateMachine } from "../StateMachine.js";
export interface StateMachineEndpointProps {
    parentResource: IResource;
    readonly resourceName: string;
    readonly method: HttpMethod;
    restApiGatewayRole: IRole;
    stateMachine: ExpressStateMachine;
}
export declare class StateMachineEndpoint extends Construct {
    resource: IResource;
    constructor(scope: Construct, id: string, props: StateMachineEndpointProps);
}
