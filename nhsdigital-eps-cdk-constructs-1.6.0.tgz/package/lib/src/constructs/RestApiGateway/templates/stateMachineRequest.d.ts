/**
 * @returns API Gateway request mapping template for StartExecution payloads.
 */
export declare const stateMachineRequestTemplate: (stateMachineArn: string) => string;
