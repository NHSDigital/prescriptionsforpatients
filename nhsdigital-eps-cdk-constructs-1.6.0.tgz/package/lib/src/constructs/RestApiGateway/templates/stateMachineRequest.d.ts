export declare const stateMachineRequestTemplate: (stateMachineArn: string) => string;
