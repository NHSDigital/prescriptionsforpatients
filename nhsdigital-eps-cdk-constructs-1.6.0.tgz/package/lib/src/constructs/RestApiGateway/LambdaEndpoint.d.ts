import { IResource } from "aws-cdk-lib/aws-apigateway";
import { IRole } from "aws-cdk-lib/aws-iam";
import { HttpMethod, IFunction } from "aws-cdk-lib/aws-lambda";
import { Construct } from "constructs";
export interface LambdaFunctionHolder {
    readonly function: IFunction;
}
export interface LambdaEndpointProps {
    parentResource: IResource;
    readonly resourceName: string;
    readonly method: HttpMethod;
    restApiGatewayRole: IRole;
    lambdaFunction: LambdaFunctionHolder;
}
export declare class LambdaEndpoint extends Construct {
    resource: IResource;
    constructor(scope: Construct, id: string, props: LambdaEndpointProps);
}
