import { ManagedPolicy } from "aws-cdk-lib/aws-iam";
import { StringParameter } from "aws-cdk-lib/aws-ssm";
import { Construct } from "constructs";
export interface SsmParameterDefinition {
    /**
     * Unique identifier used for construct and output logical IDs.
     */
    readonly id: string;
    /**
     * Suffix appended to stackName to create the parameter name.
     * The final SSM parameter name is `${stackName}-${nameSuffix}`.
     */
    readonly nameSuffix: string;
    /**
     * Description stored with the SSM parameter.
     */
    readonly description: string;
    /**
     * Value stored in the SSM parameter.
     */
    readonly value: string;
    /**
     * Optional export suffix for the output containing the parameter name.
     * Defaults to `nameSuffix`.
     */
    readonly outputExportSuffix?: string;
    /**
     * Optional output description.
     * Defaults to `description`.
     */
    readonly outputDescription?: string;
}
export interface SsmParametersConstructProps {
    /**
     * Prefix used in SSM parameter names and CloudFormation export names.
     */
    readonly namePrefix: string;
    /**
     * List of SSM parameters to create.
     */
    readonly parameters: Array<SsmParameterDefinition>;
    /**
     * Description for the managed policy that grants read access.
     * @default "Allows reading SSM parameters"
     */
    readonly readPolicyDescription?: string;
    /**
     * Description for the output exporting the managed policy ARN.
     * @default "Access to the parameters used by the integration"
     */
    readonly readPolicyOutputDescription?: string;
    /**
     * Export suffix for the output exporting the managed policy ARN.
     * @default "GetParametersPolicy"
     */
    readonly readPolicyExportSuffix?: string;
}
/**
 * Creates a bundle of SSM String parameters, a managed policy to read them,
 * and CloudFormation outputs to export parameter names and policy ARN.
 */
export declare class SsmParametersConstruct extends Construct {
    readonly parameters: Record<string, StringParameter>;
    readonly readParametersPolicy: ManagedPolicy;
    constructor(scope: Construct, id: string, props: SsmParametersConstructProps);
}
