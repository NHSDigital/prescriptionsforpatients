import { Construct } from "constructs";
import { ManagedPolicy, Role, IManagedPolicy, IRole } from "aws-cdk-lib/aws-iam";
import { Architecture, Runtime, Function as LambdaFunctionResource, ILayerVersion } from "aws-cdk-lib/aws-lambda";
import { IKey } from "aws-cdk-lib/aws-kms";
import { CfnDeliveryStream } from "aws-cdk-lib/aws-kinesisfirehose";
export interface PythonLambdaFunctionProps {
    /**
     * Name of the lambda function. The log group name is also based on this name.
     *
     */
    readonly functionName: string;
    /**
     * The base directory for resolving the package base path and entry point.
     * Should point to the monorepo root.
     */
    readonly projectBaseDir: string;
    /**
     * The relative path from projectBaseDir to the base folder where the lambda function code is located.
     *
     */
    readonly packageBasePath: string;
    /**
     * The function handler (file and method).  Example: `index.handler` for `index.py` file and `handler` method.
     */
    readonly handler: string;
    /**
     * A map of environment variables to set for the lambda function.
     */
    readonly environmentVariables?: {
        [key: string]: string;
    };
    /**
     * Optional additional IAM policies to attach to role the lambda executes as.
     */
    readonly additionalPolicies?: Array<IManagedPolicy>;
    /**
     * The number of days to retain logs in CloudWatch Logs.
     * @default 30 days
     */
    readonly logRetentionInDays: number;
    /**
     * The log level for the lambda function.
     * @default "INFO"
     */
    readonly logLevel: string;
    /**
     * Optional location of dependencies to include as a separate Lambda layer.
     */
    readonly dependencyLocation?: string;
    /**
     * Optional list of Lambda layers to attach to the function.
     */
    readonly layers?: Array<ILayerVersion>;
    /**
     * Optional timeout in seconds for the Lambda function.
     * @default 50 seconds
     */
    readonly timeoutInSeconds?: number;
    /**
     * Optional runtime for the Lambda function.
     * @default Runtime.PYTHON_3_14
     */
    readonly runtime?: Runtime;
    /**
     * Optional architecture for the Lambda function. Defaults to x86_64.
     * @default Architecture.X86_64
     */
    readonly architecture?: Architecture;
    /**
    * Any files to exclude from the Lambda asset bundle.
    * Defaults to these files
    * "tests",
    * "pytest.ini",
    * ".vscode",
    * "__pycache__",
    * "*.pyc"
    */
    readonly excludeFromAsset?: Array<string>;
    /**
     * Optional KMS key for encrypting CloudWatch Logs.
     * If not provided, the value is imported from account resources export.
     */
    readonly cloudWatchLogsKmsKey?: IKey;
    /**
     * Optional IAM policy for allowing CloudWatch to use the KMS key for encrypting logs.
     * If not provided, the value is imported from account resources export.
     */
    readonly cloudwatchEncryptionKMSPolicy?: IManagedPolicy;
    /**
     * Optional firehose delivery stream for forwarding logs to Splunk.
     * If not provided, the value is imported from account resources export.
     */
    readonly splunkDeliveryStream?: CfnDeliveryStream;
    /**
     * Optional IAM role for the subscription filter that forwards logs to Splunk.
     * If not provided, the value is imported from account resources export.
     */
    readonly splunkSubscriptionFilterRole?: IRole;
    /**
     * Optional IAM policy for allowing lambdas to use Lambda Insights log groups and streams.
     * If not provided, the value is imported from account resources export.
     */
    readonly lambdaInsightsLogGroupPolicy?: IManagedPolicy;
    /**
     * Whether to create a subscription filter on the Lambda log group to forward logs to Splunk. Defaults to true.
     */
    readonly addSplunkSubscriptionFilter?: boolean;
}
export declare class PythonLambdaFunction extends Construct {
    /**
     * The managed policy that allows execution of the Lambda function.
     *
     * Use this policy to grant other AWS resources permission to invoke this Lambda function.
     *
     * @example
     * ```typescript
     * // Grant API Gateway permission to invoke the Lambda
     * apiGatewayRole.addManagedPolicy(lambdaConstruct.executionPolicy);
     * ```
     */
    readonly executionPolicy: ManagedPolicy;
    /**
     * The Lambda function instance.
     *
     * Provides access to the underlying AWS Lambda function for additional configuration
     * or to reference its ARN, name, or other properties.
     *
     * @example
     * ```typescript
     * // Get the function ARN
     * const functionArn = lambdaConstruct.function.functionArn;
     *
     * // Add additional environment variables
     * lambdaConstruct.function.addEnvironment('NEW_VAR', 'value');
     * ```
     */
    readonly function: LambdaFunctionResource;
    /**
     * The IAM role assumed by the Lambda function during execution.
     */
    readonly executionRole: Role;
    /**
     * Creates a new PythonLambdaFunction construct.
     *
     * This construct creates:
     * - A python Lambda function with
     * - CloudWatch log group with KMS encryption
     * - Managed IAM policy for writing logs
     * - IAM role for execution with necessary permissions
     * - Subscription filter on logs so they are forwarded to splunk
     * - Managed IAM policy for invoking the Lambda function
     *
     * It also
     * - attaches the Lambda Insights layer for monitoring.
     * - adds cfnGuard suppressions for common issues.
     * - adds cdk-nag suppressions for common issues.
     *
     * @example
     * ```typescript
     * const lambdaFunction = new PythonLambdaFunction(this, 'MyFunction', {
     *   functionName: 'my-lambda',
     *   projectBaseDir: '/path/to/monorepo'
     *   packageBasePath: 'packages/my-lambda',
     *   handler: 'app.handler.handler',
     *   environmentVariables: {
     *     TABLE_NAME: 'my-table'
     *   },
     *   logRetentionInDays: 30,
     *   logLevel: 'INFO'
     * });
     * @param scope - The scope in which to define this construct
     * @param id - The scoped construct ID. Must be unique amongst siblings in the same scope
     * @param props - Configuration properties for the Lambda function
     */
    constructor(scope: Construct, id: string, props: PythonLambdaFunctionProps);
}
