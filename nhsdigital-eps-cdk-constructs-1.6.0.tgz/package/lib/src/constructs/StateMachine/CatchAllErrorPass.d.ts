import { Pass } from "aws-cdk-lib/aws-stepfunctions";
import { Construct } from "constructs";
/** Produces a fixed 500 FHIR OperationOutcome payload for unhandled workflow failures. */
export declare class CatchAllErrorPass extends Construct {
    /** Pass state returned by this construct for chaining in state machine definitions. */
    readonly state: Pass;
    /** Creates a terminal-style error response payload without exposing internal exception detail. */
    constructor(scope: Construct, id: string);
}
