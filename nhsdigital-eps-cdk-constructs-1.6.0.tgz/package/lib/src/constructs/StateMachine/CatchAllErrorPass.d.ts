import { Pass } from "aws-cdk-lib/aws-stepfunctions";
import { Construct } from "constructs";
export declare class CatchAllErrorPass extends Construct {
    readonly state: Pass;
    constructor(scope: Construct, id: string);
}
