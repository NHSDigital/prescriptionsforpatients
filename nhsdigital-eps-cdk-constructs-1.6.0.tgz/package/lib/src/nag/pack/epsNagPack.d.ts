import { NagPack, NagPackProps } from "cdk-nag";
import { IConstruct } from "constructs";
export declare class EpsNagPack extends NagPack {
    constructor(props?: NagPackProps);
    visit(node: IConstruct): void;
}
