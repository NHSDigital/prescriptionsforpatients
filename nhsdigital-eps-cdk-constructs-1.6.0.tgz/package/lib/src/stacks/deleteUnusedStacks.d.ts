/**
 * Deletes unused CloudFormation stacks and their associated Route 53 CNAME records.
 *
 * A stack is considered unused if it is a superseded version of the base stack
 * (and is not within the 24‑hour embargo window).
 *
 * @param baseStackName - Base name/prefix of the CloudFormation stacks to evaluate.
 * @param getActiveVersions - Function to get the currently active versions.
 * @param hostedZoneName - Hosted zone name used to look up Route 53 records.
 * (Only required if stacks have CNAME records that need cleaning up.)
 * @returns A promise that resolves when all eligible stacks have been processed.
 */
export declare function deleteUnusedMainStacks(baseStackName: string, getActiveVersions: () => Promise<ActiveVersions>, hostedZoneName?: string | undefined): Promise<void>;
/**
 * Deletes unused CloudFormation stacks and their associated Route 53 CNAME records.
 *
 * A stack is considered unused if it represents a pull request deployment whose PR has been closed.
 *
 * @param baseStackName - Base name/prefix of the CloudFormation stacks to evaluate.
 * @param repoName - GitHub repository name used to look up pull request state.
 * @param hostedZoneName - Hosted zone name used to look up Route 53 records.
 * (Only required if stacks have CNAME records that need cleaning up.)
 * @returns A promise that resolves when all eligible stacks have been processed.
 */
export declare function deleteUnusedPrStacks(baseStackName: string, repoName: string, hostedZoneName?: string | undefined): Promise<void>;
/**
 * Represents the currently active API versions in the base environment
 * and (optionally) the corresponding sandbox environment.
 */
export type ActiveVersions = {
    /** Currently deployed version in the base APIGEE environment (e.g. "v1.2.3"). */
    baseEnvVersion: string;
    /**
     * Currently deployed version in the sandbox APIGEE environment, or null when
     * there is no sandbox deployment for the given base environment.
     */
    sandboxEnvVersion: string | null;
};
/**
 * Fetches the active API versions from the APIM status endpoint for the
 * configured APIGEE environment, and where applicable its sandbox variant.
 *
 * The base environment is taken from `process.env.APIGEE_ENVIRONMENT`, and the
 * sandbox environment is queried for `int` ("sandbox") and `internal-dev`
 * ("internal-dev-sandbox"). Failures to resolve the sandbox version are
 * logged and surfaced as `sandboxEnvVersion: null`.
 *
 * @param basePath - Base path of the API used to build the _status URL.
 * @returns An object containing the active base and sandbox API versions.
 */
export declare function getActiveApiVersions(basePath: string): Promise<ActiveVersions>;
