import { StandardStackProps } from "../apps/createApp";
export declare function getConfigFromEnvVar(varName: string, prefix?: string): string;
export declare function getBooleanConfigFromEnvVar(varName: string, prefix?: string): boolean;
export declare function getNumberConfigFromEnvVar(varName: string, prefix?: string): number;
export declare function getTrustStoreVersion(trustStoreFile: string, region?: string): Promise<string>;
export declare function calculateVersionedStackName(baseStackName: string, props: StandardStackProps): string;
export { LAMBDA_INSIGHTS_LAYER_ARNS } from "./lambdaInsights";
