export declare const LAMBDA_INSIGHTS_LAYER_ARNS: {
    readonly x64: "arn:aws:lambda:eu-west-2:580247275435:layer:LambdaInsightsExtension:64";
    readonly arm64: "arn:aws:lambda:eu-west-2:580247275435:layer:LambdaInsightsExtension-Arm64:31";
};
