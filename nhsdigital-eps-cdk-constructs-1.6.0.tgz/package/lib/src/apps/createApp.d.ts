import { App, StackProps } from "aws-cdk-lib";
export interface StandardStackProps extends StackProps {
    /** Semantic version of the deployment (from `versionNumber`). */
    readonly version: string;
    /** Git commit identifier baked into the stack. */
    readonly commitId: string;
    /** Whether the stack originates from a pull-request environment. */
    readonly isPullRequest: boolean;
    /** Logical environment identifier (for example `dev`, `prod`). */
    readonly environment: string;
    /** CDK environment configuration used when synthesizing the stack. */
    readonly env: {
        /** AWS region targeted by the stack. */
        readonly region: string;
    };
}
export interface CreateAppParams {
    readonly productName: string;
    readonly appName: string;
    readonly repoName: string;
    readonly driftDetectionGroup: string;
    readonly region?: string;
    readonly projectType?: string;
    readonly publicFacing?: string;
    readonly serviceCategory?: string;
}
/**
 * Initialize a CDK `App` pre-loaded with NHS EPS tags and mandatory configuration.
 *
 * Reads stack metadata from environment variables, and returns
 * both the created `App` instance and the resolved stack props (including version info).
 *
 * @param params - High-level app metadata and optional deployment modifiers.
 * @param params.productName - Product tag value for the stack.
 * @param params.appName - Identifier used for `cdkApp` tagging.
 * @param params.repoName - Repository name stored on the stack tags.
 * @param params.driftDetectionGroup - Baseline drift detection tag (suffixes `-pull-request` when `isPullRequest`).
 * @param params.region - AWS region assigned to the stack environment (default `eu-west-2`).
 * @param params.projectType - Tag describing the project classification (default `Production`).
 * @param params.publicFacing - Public-facing classification tag (default `Y`).
 * @param params.serviceCategory - Service category tag (default `Platinum`).
 * @returns The constructed CDK `App` and the resolved stack props for downstream stacks.
 */
export declare function createApp({ productName, appName, repoName, driftDetectionGroup, region, projectType, publicFacing, serviceCategory }: CreateAppParams): {
    app: App;
    props: StandardStackProps;
};
